/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io.hash;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import diy.y2k.stator.io.Hasher;
import diy.y2k.stator.io.Slice;

public class JCLMacHasher implements Hasher {

	private final String algorithm;
	private final Key key;
	private final ThreadLocal<Mac> fastMac;
	private Slice emptyHash;
	
	public JCLMacHasher(String algorithm, Key key) throws NoSuchAlgorithmException, InvalidKeyException {
		Mac.getInstance(algorithm).init(key);
		this.key = key;
		this.fastMac = ThreadLocal.withInitial(() -> {
			try {
				var m = Mac.getInstance(algorithm);
				m.init(key);
				return m;
			} catch (NoSuchAlgorithmException | InvalidKeyException e) {
				throw new AssertionError(e);
			}
		});
		this.algorithm = algorithm;
	}
	
	@Override
	public Slice hash() {
		// race-y. doesn't matter
		var h = emptyHash;
		if (h == null) {
			h = hash(new byte[0], 0, 0);
			emptyHash = h;
			return h;
		}
		return h;
	}
	
	@Override
	public Slice hash(byte[] bytes, int offset, int length) {
		var mac = fastMac.get();
		try {
			mac.update(bytes, offset, length);
			return new Slice(mac.doFinal());
		} finally {
			mac.reset();
		}
	}

	@Override
	public Session newSession() {
		try {
			var digest = Mac.getInstance(algorithm);
			digest.init(key);
			return new Session() {
				@Override
				public void putBytes(byte[] bytes, int offset, int length) { digest.update(bytes, offset, length); }
				@Override
				public Slice finish() { return new Slice(digest.doFinal()); }
			};
		} catch (NoSuchAlgorithmException | InvalidKeyException e) {
			throw new AssertionError(e);
		}
	}
	
	@Override
	public String toString() {
		return "JCLHasher["+algorithm+"]";
	}

	public static JCLMacHasher create(String algorithm, Key key) {
		try {
			return new JCLMacHasher(algorithm, key);
		} catch (NoSuchAlgorithmException | InvalidKeyException e) {
			throw new IllegalArgumentException(e);
		}
	}

	public static JCLMacHasher create(String algorithm, byte[] key) {
		return create(algorithm, new SecretKeySpec(key, "RAW"));
	}

}
