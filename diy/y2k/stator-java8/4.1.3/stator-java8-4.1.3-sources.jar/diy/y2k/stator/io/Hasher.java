/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io;

import java.nio.charset.StandardCharsets;

import diy.y2k.stator.distill.Distillable;
import diy.y2k.stator.distill.Still;

public interface Hasher {
	Session newSession();
	
	default Slice hash(byte[] bytes, int offset, int length) {
		var sess = newSession();
		sess.putBytes(bytes, offset, length);
		return sess.finish();
	}
	
	/**
	 * @return the hash of an empty input
	 */
	Slice hash();
	
	default Slice hash(byte[] bytes) { return hash(bytes, 0, bytes.length); }
	default Slice hashUtf8(String str) { return hash(str.getBytes(StandardCharsets.UTF_8)); }
	default Slice hashUtf16(String str) { return hash(str.getBytes(StandardCharsets.UTF_16)); }
	default Slice hash(Slice slice) { return hash(slice.getArray(), slice.getOffset(), slice.size()); }
	
	default Slice hash(int i) { return hash(Bytes.intToByteArray(i)); }
	default Slice hash(long i) { return hash(Bytes.longToByteArray(i)); }
	default Slice hash(float i) { return hash(Bytes.intToByteArray(Float.floatToIntBits(i))); }
	default Slice hash(double i) { return hash(Bytes.longToByteArray(Double.doubleToLongBits(i))); }
	
	default Slice hash(Distillable d) {
		var sess = newSession();
		d.distill(sess);
		return sess.finish();
	}
	
	public interface Session extends Still {
		Slice finish();
		
		@Override
		default void putBoolean(boolean b) {
			putByte((byte)(b ? 1 : 0));
		}
		@Override
		default void putByte(byte b) {
			putBytes(new byte[] {b});
		}
		@Override
		default void putChar(char c) {
			putBytes(Bytes.shortToByteArray((short)c));
		}
		@Override
		default void putShort(short s) {
			putBytes(Bytes.shortToByteArray(s));
		}
		@Override
		default void putInt(int i) {
			putBytes(Bytes.intToByteArray(i));
		}
		@Override
		default void putLong(long l) {
			putBytes(Bytes.longToByteArray(l));
		}
		@Override
		default void putFloat(float f) {
			putBytes(Bytes.intToByteArray(Float.floatToIntBits(f)));
		}
		@Override
		default void putDouble(double d) {
			putBytes(Bytes.longToByteArray(Double.doubleToLongBits(d)));
		}
		@Override
		default void putBooleans(boolean[] b, int ofs, int len) {
			byte[] bys = new byte[len*1];
			for (int i = 0; i < len; i++) {
				bys[i] = (byte)(b[ofs+i] ? 1 : 0);
			}
		}
		@Override
		default void putChars(char[] c, int ofs, int len) {
			byte[] bys = new byte[len*2];
			for (int i = 0; i < len; i++) {
				Bytes.putShort((short)c[ofs+i], bys, i*2);
			}
		}
		@Override
		default void putShorts(short[] s, int ofs, int len) {
			byte[] bys = new byte[len*2];
			for (int i = 0; i < len; i++) {
				Bytes.putShort(s[ofs+i], bys, i*2);
			}
		}
		@Override
		default void putInts(int[] a, int ofs, int len) {
			byte[] bys = new byte[len*4];
			for (int i = 0; i < len; i++) {
				Bytes.putInt(a[ofs+i], bys, i*4);
			}
		}
		@Override
		default void putLongs(long[] l, int ofs, int len) {
			byte[] bys = new byte[len*8];
			for (int i = 0; i < len; i++) {
				Bytes.putLong(l[ofs+i], bys, i*8);
			}
		}
		@Override
		default void putFloats(float[] f, int ofs, int len) {
			byte[] bys = new byte[len*4];
			for (int i = 0; i < len; i++) {
				Bytes.putInt(Float.floatToIntBits(f[ofs+i]), bys, i*4);
			}
		}
		@Override
		default void putDoubles(double[] d, int ofs, int len) {
			byte[] bys = new byte[len*8];
			for (int i = 0; i < len; i++) {
				Bytes.putLong(Double.doubleToLongBits(d[ofs+i]), bys, i*8);
			}
		}
		@Override
		default void put(String s) {
			putBytes(s.getBytes(StandardCharsets.UTF_8));
		}
		@Override
		default void put(Slice s) {
			putBytes(s.getArray(), s.getOffset(), s.size());
		}
		@Override
		default void put(Distillable d) {
			if (d != null) d.distill(this);
		}
		
	}
}
