/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io.hash;

import diy.y2k.stator.io.Bytes;
import diy.y2k.stator.io.Slice;

public class Murmur3_x86_32Hasher implements BufferedHasher {
	
	private final int seed;
	private final Slice emptyHash;

	public Murmur3_x86_32Hasher(int seed) {
		this.seed = seed;
		this.emptyHash = hash(new byte[0], 0, 0);
	}
	
	@Override
	public Slice hash() {
		return emptyHash;
	}

	@Override
	public Slice hash(byte[] bytes, int offset, int length) {
		return new Slice(murmurhash3_x86_32(bytes, offset, length, seed));
	}
	
	@Override
	public String toString() {
		return "Murmur3_x86_32Hasher["+seed+"]";
	}
	
	// https://github.com/eprst/murmur3/blob/0bc61bd5f11a828574d6620659a07faf230b41f6/src/main/java/com/github/eprst/murmur3/MurmurHash3.java
	
	static byte[] murmurhash3_x86_32(byte[] data, int offset, int len, int seed) {
		final int c1 = 0xcc9e2d51;
		final int c2 = 0x1b873593;

		int h1 = seed;
		int roundedEnd = offset + (len & 0xfffffffc);	// round down to 4 byte block

		for (int i = offset; i < roundedEnd; i += 4) {
			// little endian load order
			int k1 = (data[i] & 0xff) | ((data[i + 1] & 0xff) << 8) | ((data[i + 2] & 0xff) << 16) | (data[i + 3] << 24);
			k1 *= c1;
			k1 = (k1 << 15) | (k1 >>> 17);	// ROTL32(k1,15);
			k1 *= c2;

			h1 ^= k1;
			h1 = (h1 << 13) | (h1 >>> 19);	// ROTL32(h1,13);
			h1 = h1 * 5 + 0xe6546b64;
		}

		// tail
		int k1 = 0;

		switch (len & 0x03) {
			case 3:
				k1 = (data[roundedEnd + 2] & 0xff) << 16;
				// fallthrough
			case 2:
				k1 |= (data[roundedEnd + 1] & 0xff) << 8;
				// fallthrough
			case 1:
				k1 |= (data[roundedEnd] & 0xff);
				k1 *= c1;
				k1 = (k1 << 15) | (k1 >>> 17);	// ROTL32(k1,15);
				k1 *= c2;
				h1 ^= k1;
		}

		// finalization
		h1 ^= len;

		// fmix(h1);
		h1 ^= h1 >>> 16;
		h1 *= 0x85ebca6b;
		h1 ^= h1 >>> 13;
		h1 *= 0xc2b2ae35;
		h1 ^= h1 >>> 16;

		return Bytes.intToByteArray(h1);
	}

}
