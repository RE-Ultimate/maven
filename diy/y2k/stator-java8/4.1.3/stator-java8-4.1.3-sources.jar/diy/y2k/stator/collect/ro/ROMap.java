/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.ro;

import java.util.AbstractMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

import diy.y2k.stator.exception.ReadOnlyException;

/**
 * A read-only/"unmodifiable" map that codifies that immutability into its API contract.
 */
@SuppressWarnings("unlikely-arg-type")
public final class ROMap<K, V> implements Map<K, V> {
	private final Map<K, V> underlying;
	private final ROSet<K> keySet;
	private final ROSet<Entry<K, V>> entrySet;
	private final ROCollection<V> values;
	
	ROMap(Map<K, V> underlying) {
		this.underlying = underlying;
		this.keySet = new ROSet<>(underlying.keySet(), null);
		this.entrySet = new ROSet<>(underlying.entrySet(), AbstractMap.SimpleImmutableEntry::new);
		this.values = new ROCollection<>(underlying.values());
	}
	
	@Override
	public ROSet<K> keySet() { return keySet; }
	@Override
	public ROSet<Entry<K, V>> entrySet() { return entrySet; }
	@Override
	public ROCollection<V> values() { return values; }
	@Override
	public String toString() { return underlying.toString(); }
	
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public void clear() { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V put(K key, V value) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public void putAll(Map<? extends K, ? extends V> m) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V remove(Object key) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V putIfAbsent(K key, V value) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public boolean remove(Object key, Object value) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public boolean replace(K key, V oldValue, V newValue) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public V replace(K key, V value) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) { throw new ReadOnlyException(); }

	@Override
	public int size() { return underlying.size(); }
	@Override
	public boolean isEmpty() { return underlying.isEmpty(); }
	@Override
	public boolean containsKey(Object key) { return underlying.containsKey(key); }
	@Override
	public boolean containsValue(Object value) { return underlying.containsValue(value); }
	@Override
	public V get(Object key) { return underlying.get(key); }
	@Override
	public boolean equals(Object o) { return underlying.equals(o); }
	@Override
	public int hashCode() { return underlying.hashCode(); 	}
	@Override
	public V getOrDefault(Object key, V defaultValue) { return underlying.getOrDefault(key, defaultValue); }
	@Override
	public void forEach(BiConsumer<? super K, ? super V> action) { underlying.forEach(action); }
}
