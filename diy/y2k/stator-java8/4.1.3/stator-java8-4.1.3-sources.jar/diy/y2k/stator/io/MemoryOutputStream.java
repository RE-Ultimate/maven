/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;
import org.checkerframework.checker.mustcall.qual.NotOwning;

/**
 * A faster ByteArrayOutputStream that doesn't do massive copies when its current capacity is
 * exceeded, and isn't synchronized.
 */
// inspired by jdk discussion about a new faster baos, but not based on any of their code
public class MemoryOutputStream extends OutputStream {
	public interface ChunkProcessor extends IOChunkProcessor {
		@Override
		void process(byte[] bys, int ofs, int len);
	}
	
	public interface IOChunkProcessor {
		void process(byte[] bys, int ofs, int len) throws IOException;
	}
	
	public static final int DEFAULT_CHUNK_SIZE = 1024;
	
	private final List<byte[]> chunks = new ArrayList<>();
	private final int chunkSize;
	
	private long index;
	private int indexIntoChunk = -1;
	private byte[] currentChunk;
	
	public MemoryOutputStream() {
		this(DEFAULT_CHUNK_SIZE);
	}
	
	public MemoryOutputStream(int chunkSize) {
		this.chunkSize = chunkSize;
	}
	
	public long size() {
		return index;
	}
	
	public void processChunks(ChunkProcessor proc) {
		try {
			processChunksIO(proc);
		} catch (IOException e) {
			throw new AssertionError(e);
		}
	}
	
	public void processChunksIO(IOChunkProcessor proc) throws IOException {
		for (var c : chunks) {
			var l = c == currentChunk ? indexIntoChunk : c.length;
			if (l <= 0) continue;
			proc.process(c, 0, l);
		}
	}
	
	public void transferTo(@NotOwning OutputStream stream) throws IOException {
		processChunksIO(stream::write);
	}
	
	public byte[] toByteArray() {
		if (index > Integer.MAX_VALUE) throw new IllegalArgumentException("Cannot store "+index+" bytes into a byte array");
		var out = new byte[(int)index];
		processChunks(new ChunkProcessor() {
			int i = 0;
			@Override
			public void process(byte[] bys, int ofs, int len) {
				System.arraycopy(bys, ofs, out, i, len);
				i += len;
			}
		});
		return out;
	}

	@Override
	public void write(int b) {
		if (indexIntoChunk < 0 || indexIntoChunk >= chunkSize) {
			createChunk();
		}
		currentChunk[indexIntoChunk] = (byte)b;
		index++;
		indexIntoChunk++;
	}

	@Override
	public void write(byte[] b) {
		write(b, 0, b.length);
	}
	
	@Override
	public void write(byte[] b, int off, int len) {
		int max = chunkSize-indexIntoChunk;
		if (currentChunk == null) {
			writeAsNewChunkIfLarge(b, off, len);
		} else if (len < max) {
			writeIntoCurrentChunk(b, off, len);
		} else {
			writeIntoCurrentChunk(b, off, max);
			endChunk();
			writeAsNewChunkIfLarge(b, off+max, len-max);
		}
	}
	
	private void createChunk() {
		chunks.add(currentChunk = new byte[chunkSize]);
		indexIntoChunk = 0;
	}
	
	private void endChunk() {
		indexIntoChunk = -1;
		currentChunk = null;
	}

	private void writeAsNewChunkIfLarge(byte[] b, int off, int len) {
		if (len < chunkSize) {
			createChunk();
			writeIntoCurrentChunk(b, off, len);
		} else {
			var copy = new byte[len];
			System.arraycopy(b, off, copy, 0, len);
			index += len;
			chunks.add(copy);
		}
	}
	
	private void writeIntoCurrentChunk(byte[] b, int off, int len) {
		System.arraycopy(b, off, currentChunk, indexIntoChunk, len);
		indexIntoChunk += len;
		index += len;
	}
	
	@Override
	public void flush() {}
	
	@Override
	public void close() {}
	
	@Override
	public String toString() {
		var sj = new StringJoiner(",");
		processChunks((b, off, len) -> {
			sj.add(Integer.toString(len));
		});
		return "MemoryOutputStream[size="+size()
				+ ",chunking=["+chunks.size()+"x;"+sj+"]"
				+ ",wastedSpace="+(currentChunk == null ? 0 : currentChunk.length-indexIntoChunk)+"]";
	}
	
}
