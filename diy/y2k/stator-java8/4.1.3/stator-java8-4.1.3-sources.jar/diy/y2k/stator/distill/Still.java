/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.distill;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

import diy.y2k.stator.io.Slice;

/**
 * An ordered stream of primitives.
 */
public interface Still {

	void putBoolean(boolean b);
	void putByte(byte b);
	void putChar(char c);
	void putShort(short s);
	void putInt(int i);
	void putLong(long l);
	void putFloat(float f);
	void putDouble(double d);

	void putBooleans(@NonNull boolean[] b, int ofs, int len);
	void putBytes(@NonNull byte[] b, int ofs, int len);
	void putChars(@NonNull char[] c, int ofs, int len);
	void putShorts(@NonNull short[] s, int ofs, int len);
	void putInts(@NonNull int[] i, int ofs, int len);
	void putLongs(@NonNull long[] l, int ofs, int len);
	void putFloats(@NonNull float[] f, int ofs, int len);
	void putDoubles(@NonNull double[] d, int ofs, int len);

	default void putBooleans(@NonNull boolean[] b) { putBooleans(b, 0, b.length); }
	default void putBytes(@NonNull byte[] b) { putBytes(b, 0, b.length); }
	default void putChars(@NonNull char[] c) { putChars(c, 0, c.length); }
	default void putShorts(@NonNull short[] s) { putShorts(s, 0, s.length); }
	default void putInts(@NonNull int[] i) { putInts(i, 0, i.length); }
	default void putLongs(@NonNull long[] l) { putLongs(l, 0, l.length); }
	default void putFloats(@NonNull float[] f) { putFloats(f, 0, f.length); }
	default void putDoubles(@NonNull double[] d) { putDoubles(d, 0, d.length); }
	
	void put(@Nullable String s);
	void put(@Nullable Slice s);
	void put(@Nullable Distillable d);

}
