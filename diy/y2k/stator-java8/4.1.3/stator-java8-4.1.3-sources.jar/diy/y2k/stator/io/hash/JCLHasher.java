/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io.hash;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import diy.y2k.stator.io.Hasher;
import diy.y2k.stator.io.Slice;

public class JCLHasher implements Hasher {

	private final String algorithm;
	private final ThreadLocal<MessageDigest> fastDigest;
	private Slice emptyHash;
	
	public JCLHasher(String algorithm) throws NoSuchAlgorithmException {
		MessageDigest.getInstance(algorithm);
		this.fastDigest = ThreadLocal.withInitial(() -> {
			try {
				return MessageDigest.getInstance(algorithm);
			} catch (NoSuchAlgorithmException e) {
				throw new AssertionError(e);
			}
		});
		this.algorithm = algorithm;
	}
	
	@Override
	public Slice hash() {
		// race-y. doesn't matter
		var h = emptyHash;
		if (h == null) {
			h = hash(new byte[0], 0, 0);
			emptyHash = h;
			return h;
		}
		return h;
	}
	
	@Override
	public Slice hash(byte[] bytes, int offset, int length) {
		var digest = fastDigest.get();
		try {
			digest.update(bytes, offset, length);
			return new Slice(digest.digest());
		} finally {
			digest.reset();
		}
	}

	@Override
	public Session newSession() {
		try {
			var digest = MessageDigest.getInstance(algorithm);
			return new Session() {
				@Override
				public void putBytes(byte[] bytes, int offset, int length) { digest.update(bytes, offset, length); }
				@Override
				public Slice finish() { return new Slice(digest.digest()); }
			};
		} catch (NoSuchAlgorithmException e) {
			throw new AssertionError(e);
		}
	}
	
	@Override
	public String toString() {
		return "JCLHasher["+algorithm+"]";
	}

	public static JCLHasher create(String algorithm) {
		try {
			return new JCLHasher(algorithm);
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalArgumentException(e);
		}
	}

}
