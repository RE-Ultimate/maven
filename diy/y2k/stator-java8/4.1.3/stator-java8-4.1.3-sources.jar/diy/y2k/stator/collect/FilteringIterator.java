/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Predicate;

public class FilteringIterator<T> implements Iterator<T> {
	private final Iterator<T> underlying;
	private final Predicate<T> filter;

	private static final Object UNKNOWN = new Object();
	private static final Object END = new Object();
	private Object next = UNKNOWN;
	
	public FilteringIterator(Iterator<T> underlying, Predicate<T> filter) {
		this.underlying = underlying;
		this.filter = filter;
	}

	@Override
	public boolean hasNext() {
		if (next == END) return false;
		if (next == UNKNOWN) {
			while (underlying.hasNext()) {
				var maybeNext = underlying.next();
				if (filter.test(maybeNext)) {
					next = maybeNext;
					return true;
				}
			}
			next = END;
			return false;
		}
		return true;
	}

	@Override
	public T next() {
		if (!hasNext()) throw new NoSuchElementException();
		@SuppressWarnings("unchecked") // safe if hasNext returns true
		var t = (T)next;
		next = UNKNOWN;
		return t;
	}

	@Override
	public void remove() {
		if (next != UNKNOWN) throw new IllegalStateException();
		underlying.remove();
	}
	
}