/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io.hash;

import java.security.Key;
import java.util.Optional;

import diy.y2k.stator.io.Hasher;

public final class StandardHashers {
	private static final Hasher MD2 = JCLHasher.create("MD2");
	private static final Hasher MD5 = JCLHasher.create("MD5");
	private static final Hasher SHA1 = JCLHasher.create("SHA-1");

	private static final Hasher SHA2_224 = JCLHasher.create("SHA-224");
	private static final Hasher SHA2_256 = JCLHasher.create("SHA-256");
	
	private static final Hasher SHA2_384 = JCLHasher.create("SHA-384");
	private static final Hasher SHA2_512 = JCLHasher.create("SHA-512");
	
	private static final Optional<Hasher> SHA2_512_224;
	private static final Optional<Hasher> SHA2_512_256;
	
	static {
		// added in later Java 8 builds, not available in some old JRE distributions (e.g. Mojang)
		Optional<Hasher> sha2_512_224_tmp;
		Optional<Hasher> sha2_512_256_tmp;
		try {
			sha2_512_224_tmp = Optional.of(JCLHasher.create("SHA-512/224"));
			sha2_512_256_tmp = Optional.of(JCLHasher.create("SHA-512/256"));
		} catch (IllegalArgumentException e) {
			sha2_512_224_tmp = Optional.empty();
			sha2_512_256_tmp = Optional.empty();
		}
		SHA2_512_224 = sha2_512_224_tmp;
		SHA2_512_256 = sha2_512_256_tmp;
	}

	private static final Hasher MURMUR3_x64_128 = new Murmur3_x64_128Hasher(0);
	private static final Hasher MURMUR3_x86_32 = new Murmur3_x86_32Hasher(0);
	
	@Deprecated
	public static Hasher md2() { return MD2; }
	@Deprecated
	public static Hasher md5() { return MD5; }
	public static Hasher sha1() { return SHA1; }
	public static Hasher sha2_224() { return SHA2_224; }
	public static Hasher sha2_256() { return SHA2_256; }
	public static Hasher sha2_384() { return SHA2_384; }
	public static Hasher sha2_512() { return SHA2_512; }
	
	public static Hasher sha2_512_224() { return SHA2_512_224.get(); }
	public static Hasher sha2_512_256() { return SHA2_512_256.get(); }
	
	public static Hasher murmur3_x86_32() { return MURMUR3_x86_32; }
	public static Hasher murmur3_x86_32(int seed) { return new Murmur3_x86_32Hasher(seed); }
	
	public static Hasher murmur3_x64_128() { return MURMUR3_x64_128; }
	public static Hasher murmur3_x64_128(int seed) { return new Murmur3_x64_128Hasher(seed); }

	public static Hasher siphash(int c, int d, byte[] key) { return new SipHashHasher(key, c, d); }
	
	public static Hasher siphash_1_3(byte[] key) { return new SipHashHasher(key, 1, 3); }
	public static Hasher siphash_2_4(byte[] key) { return new SipHashHasher(key, 2, 4); }
	public static Hasher siphash_4_8(byte[] key) { return new SipHashHasher(key, 4, 8); }
	
	@Deprecated
	public static Hasher hmac_md5(Key key) { return JCLMacHasher.create("HmacMD5", key); }
	@Deprecated
	public static Hasher hmac_md5(byte[] key) { return JCLMacHasher.create("HmacMD5", key); }
	
	@Deprecated
	public static Hasher hmac_sha1(Key key) { return JCLMacHasher.create("HmacSHA1", key); }
	@Deprecated
	public static Hasher hmac_sha1(byte[] key) { return JCLMacHasher.create("HmacSHA1", key); }
	
	public static Hasher hmac_sha2_224(Key key) { return JCLMacHasher.create("HmacSHA224", key); }
	public static Hasher hmac_sha2_224(byte[] key) { return JCLMacHasher.create("HmacSHA224", key); }
	
	public static Hasher hmac_sha2_256(Key key) { return JCLMacHasher.create("HmacSHA256", key); }
	public static Hasher hmac_sha2_256(byte[] key) { return JCLMacHasher.create("HmacSHA256", key); }
	
	public static Hasher hmac_sha2_384(Key key) { return JCLMacHasher.create("HmacSHA384", key); }
	public static Hasher hmac_sha2_384(byte[] key) { return JCLMacHasher.create("HmacSHA384", key); }
	
	public static Hasher hmac_sha2_512(Key key) { return JCLMacHasher.create("HmacSHA512", key); }
	public static Hasher hmac_sha2_512(byte[] key) { return JCLMacHasher.create("HmacSHA512", key); }
	



























	







	
	private StandardHashers() {}
}
