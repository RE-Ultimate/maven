/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io;

public class BytesLE {

	public static byte[] shortToByteArray(short v) {
		var arr = new byte[2];
		putShort(v, arr, 0);
		return arr;
	}

	public static byte[] intToByteArray(int v) {
		var arr = new byte[4];
		putInt(v, arr, 0);
		return arr;
	}

	public static byte[] longToByteArray(long v) {
		var arr = new byte[8];
		putLong(v, arr, 0);
		return arr;
	}
	
	public static void putShort(short v, byte[] target, int ofs) {
		target[ofs+0] = (byte)(v >>>  0);
		target[ofs+1] = (byte)(v >>>  8);
	}
	
	public static void putInt(int v, byte[] target, int ofs) {
		target[ofs+0] = (byte)(v >>>  0);
		target[ofs+1] = (byte)(v >>>  8);
		target[ofs+2] = (byte)(v >>> 16);
		target[ofs+3] = (byte)(v >>> 24);
	}

	public static void putLong(long v, byte[] target, int ofs) {
		target[ofs+0] = (byte)(v >>>  0);
		target[ofs+1] = (byte)(v >>>  8);
		target[ofs+2] = (byte)(v >>> 16);
		target[ofs+3] = (byte)(v >>> 24);
		target[ofs+4] = (byte)(v >>> 32);
		target[ofs+5] = (byte)(v >>> 40);
		target[ofs+6] = (byte)(v >>> 48);
		target[ofs+7] = (byte)(v >>> 56);
	}
	
	public static short getShort(byte[] source, int ofs) {
		return (short)(((source[ofs+0] & 0xFF) << 0) |
		               ((source[ofs+1] & 0xFF) << 8));
	}
	
	public static int getInt(byte[] source, int ofs) {
		return (((source[ofs+0] & 0xFF) <<  0) |
		        ((source[ofs+1] & 0xFF) <<  8) |
		        ((source[ofs+2] & 0xFF) << 16) |
		        ((source[ofs+3] & 0xFF) << 24));
	}
	
	public static long getLong(byte[] source, int ofs) {
		return (((long) (source[ofs+0] & 0xFF) <<  0) |
		        ((long) (source[ofs+1] & 0xFF) <<  8) |
		        ((long) (source[ofs+2] & 0xFF) << 16) |
		        ((long) (source[ofs+3] & 0xFF) << 24) |
		        ((long) (source[ofs+4] & 0xFF) << 32) |
		        ((long) (source[ofs+5] & 0xFF) << 40) |
		        ((long) (source[ofs+6] & 0xFF) << 48) |
		        ((long) (source[ofs+7] & 0xFF) << 56));
	}
	
	private BytesLE() {}
	
}
