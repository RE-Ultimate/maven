/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.distill;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import diy.y2k.stator.io.Slice;

public class EqualsStill implements FlexibleStill {

	private final List<Object> template = new ArrayList<>();
	private int index = 0;
	private boolean swapped = false;
	private boolean notEqual = false;
	
	public void swap() {
		swapped = true;
	}

	private void process(Object o) {
		if (swapped) {
			if (notEqual) return;
			if (index >= template.size()) {
				notEqual = true;
				return;
			}
			var obj = template.get(index);
			if (!Objects.deepEquals(o, obj)) {
				notEqual = true;
			}
			index++;
		} else {
			template.add(o);
		}
	}

	@Override
	public void putBoolean(boolean b) {
		process(b);
	}
	
	@Override
	public void putByte(byte b) {
		process(b);
	}

	@Override
	public void putChar(char c) {
		process(c);
	}

	@Override
	public void putShort(short s) {
		process(s);
	}

	@Override
	public void putInt(int i) {
		process(i);
	}

	@Override
	public void putLong(long l) {
		process(l);
	}

	@Override
	public void putFloat(float f) {
		process(f);
	}

	@Override
	public void putDouble(double d) {
		process(d);
	}

	@Override
	public void putBooleans(boolean[] b, int ofs, int len) {
		process(Arrays.copyOfRange(b, ofs, ofs+len));
	}

	@Override
	public void putBytes(byte[] b, int ofs, int len) {
		process(Arrays.copyOfRange(b, ofs, ofs+len));
	}

	@Override
	public void putChars(char[] c, int ofs, int len) {
		process(Arrays.copyOfRange(c, ofs, ofs+len));
	}

	@Override
	public void putShorts(short[] s, int ofs, int len) {
		process(Arrays.copyOfRange(s, ofs, ofs+len));
	}

	@Override
	public void putInts(int[] i, int ofs, int len) {
		process(Arrays.copyOfRange(i, ofs, ofs+len));
	}

	@Override
	public void putLongs(long[] l, int ofs, int len) {
		process(Arrays.copyOfRange(l, ofs, ofs+len));
	}

	@Override
	public void putFloats(float[] f, int ofs, int len) {
		process(Arrays.copyOfRange(f, ofs, ofs+len));
	}

	@Override
	public void putDoubles(double[] d, int ofs, int len) {
		process(Arrays.copyOfRange(d, ofs, ofs+len));
	}

	@Override
	public void put(String s) {
		process("string");
		process(s);
	}
	
	@Override
	public void put(Slice s) {
		process("slice");
		process(s);
	}
	
	@Override
	public void putNonDistillable(Object o) {
		if (o == null) {
			process(null);
			process(null);
		} else {
			process(o.getClass());
			process(o);
		}
	}

	@Override
	public void put(Distillable d) {
		if (d == null) {
			process(null);
			process(null);
		} else {
			process(d.getClass());
			d.distill(this);
		}
	}
	
	public boolean equals() {
		return !notEqual;
	}
	
}
