/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.multi;

import java.util.AbstractSet;
import java.util.StringJoiner;

import diy.y2k.stator.distill.FlexibleStill;
import diy.y2k.stator.distill.InternalDistillable;

public abstract class AbstractMultiset<E> extends AbstractSet<E> implements Multiset<E> {

	/**
	 * {@inheritDoc}
	 * @implNote Delegates to {@code add(o, 1)}.
	 */
	@Override
	public boolean add(E e) {
		add(e, 1);
		return true;
	}

	/**
	 * {@inheritDoc}
	 * @implNote Delegates to {@code remove(o, 1)}.
	 */
	@Override
	public boolean remove(Object o) {
		return remove(o, 1) > 0;
	}

	/**
	 * {@inheritDoc}
	 * @implNote This implementation is <i>not atomic</i>.
	 */
	@Override
	public int exchangeCount(E element, int expectedCount, int newCount) {
		int oldCount = count(element);
		if (oldCount == expectedCount) {
			setCount(element, newCount);
		}
		return oldCount;
	}
	
	@Override
	public String toString() {
		var sj = new StringJoiner(", ", "[", "]");
		for (var en : entrySet()) {
			sj.add(en.element()+":"+en.count());
		}
		return sj.toString();
	}
	
	public static class Entry<E> extends InternalDistillable implements Multiset.Entry<E> {

		private final E element;
		private final int count;
		
		public Entry(E element, int count) {
			this.element = element;
			this.count = count;
		}

		@Override
		public E element() {
			return element;
		}

		@Override
		public int count() {
			return count;
		}
		
		@Override
		protected void distill(FlexibleStill out) {
			out.putNonDistillable(element);
			out.putInt(count);
		}
		
		@Override
		public String toString() {
			return element+":"+count;
		}
		
	}
	
}
