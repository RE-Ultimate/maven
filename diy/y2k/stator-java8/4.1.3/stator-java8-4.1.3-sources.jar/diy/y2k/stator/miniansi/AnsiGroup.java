/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.miniansi;

import java.util.ArrayList;
import java.util.List;

import diy.y2k.stator.collect.ro.ROList;
import diy.y2k.stator.collect.ro.ReadOnly;

public final class AnsiGroup implements Ansi {
	private final AnsiCode[] codes;
	public AnsiGroup(AnsiCode... codes) {
		this.codes = codes;
	}
	@Override
	public String toString() {
		return Ansi.toString(codes);
	}
	@Override
	public ROList<Integer> getCodes() {
		List<Integer> li = new ArrayList<>();
		for (AnsiCode code : codes) {
			li.addAll(code.getCodes());
		}
		return ReadOnly.copyOf(li);
	}
}
