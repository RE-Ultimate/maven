/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.ro;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.RandomAccess;
import java.util.function.UnaryOperator;

import diy.y2k.stator.exception.ReadOnlyException;

/**
 * A read-only/"unmodifiable" list that codifies that immutability into its API contract.
 */
@SuppressWarnings("unlikely-arg-type")
public final class ROList<E> extends ROCollection<E> implements List<E>, RandomAccess {
	private final List<E> underlying;
	
	ROList(List<E> underlying) {
		super(underlying);
		this.underlying = underlying;
		if (underlying instanceof ArrayList a) {
			a.trimToSize();
		}
	}

	@Override
	public ROListIterator<E> listIterator() { return new ROListIterator<>(underlying.listIterator()); }
	@Override
	public ROListIterator<E> listIterator(int index) { return new ROListIterator<>(underlying.listIterator(index)); }
	@Override
	public ROList<E> subList(int fromIndex, int toIndex) { return new ROList<>(underlying.subList(fromIndex, toIndex)); }
	
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public void add(int index, E element) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public boolean addAll(int index, Collection<? extends E> c) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public E remove(int index) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public E set(int index, E element) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public void replaceAll(UnaryOperator<E> operator) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public void sort(Comparator<? super E> c) { throw new ReadOnlyException(); }
	
	@Override
	public E get(int index) { return underlying.get(index); }
	@Override
	public int indexOf(Object o) { return underlying.indexOf(o); }
	@Override
	public int lastIndexOf(Object o) { return underlying.lastIndexOf(o); }
}
