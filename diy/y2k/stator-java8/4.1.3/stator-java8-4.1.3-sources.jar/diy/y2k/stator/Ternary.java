/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator;

public enum Ternary {
	YES,
	NO,
	MAYBE;
	
	public boolean resolve(boolean fallback) {
		if (this == YES) return true;
		if (this == NO) return false;
		return fallback;
	}
	
	public boolean or(Ternary other) {
		return this == YES || other == YES;
	}
	
	public boolean and(Ternary other) {
		return this == YES && other == YES;
	}
	
	public Ternary not() {
		if (this == YES) return NO;
		if (this == NO) return YES;
		return MAYBE;
	}
}
