/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.io.hash;

import diy.y2k.stator.io.BytesLE;
import diy.y2k.stator.io.Hasher;
import diy.y2k.stator.io.Slice;

// Based on https://github.com/whitfin/siphash-java/blob/7ce4103d45c56ae664a15716112b791d236eeb22/src/main/java/io/whitfin/siphash/SipHash.java
// The outer Hasher instance acts like a SipHashContext, and a Session acts like a SipHashStream
public class SipHashHasher implements Hasher {
	
	private final int c, d;
	private final Slice emptyHash;
	
	private final long init_v0, init_v1, init_v2, init_v3;

	public SipHashHasher(byte[] key) {
		this(key, DEFAULT_C, DEFAULT_D);
	}

	public SipHashHasher(byte[] key, int c, int d) {
		if (key.length != 16) throw new IllegalArgumentException("Key must be exactly 16 bytes");
		long k0 = BytesLE.getLong(key, 0);
		long k1 = BytesLE.getLong(key, 8);
		this.c = c;
		this.d = d;
		
		this.init_v0 = INITIAL_V0 ^ k0;
		this.init_v1 = INITIAL_V1 ^ k1;
		this.init_v2 = INITIAL_V2 ^ k0;
		this.init_v3 = INITIAL_V3 ^ k1;
		
		this.emptyHash = new Slice(BytesLE.longToByteArray(siphash(c, d, init_v0, init_v1, init_v2, init_v3, new byte[0])));
	}

	@Override
	public Session newSession() {
		return new Session() {
			@Override
			public Slice finish() {
				byte msgLenMod256 = this.len;

				while (this.m_idx < 7) {
					putByte((byte) 0);
				}
				putByte(msgLenMod256);

				this.v2 ^= 0xff;
				for (int i = 0; i < d; i++) {
					round();
				}

				return new Slice(BytesLE.longToByteArray(this.v0 ^ this.v1 ^ this.v2 ^ this.v3));
			}
			
			@Override
			public void putBytes(byte[] bytes, int offset, int length) {
				for (int i = 0; i < length; i++) {
					putByte(bytes[offset+i]);
				}
			}
			
			@Override
			public void putByte(byte b) {
				this.len++;
				this.m |= (((long) b & 0xff) << (this.m_idx++ * 8));
				if (this.m_idx < 8) {
					return;
				}
				this.v3 ^= this.m;
				for (int i = 0; i < c; i++) {
					round();
				}
				this.v0 ^= this.m;
				this.m_idx = 0;
				this.m = 0;
			}

			private byte len = 0;
			private int m_idx = 0;
			private long m = 0;
			private long v0 = init_v0;
			private long v1 = init_v1;
			private long v2 = init_v2;
			private long v3 = init_v3;
			
			private void round() {
				this.v0 += this.v1;
				this.v2 += this.v3;
				this.v1 = rotateLeft(this.v1, 13);
				this.v3 = rotateLeft(this.v3, 16);

				this.v1 ^= this.v0;
				this.v3 ^= this.v2;
				this.v0 = rotateLeft(this.v0, 32);

				this.v2 += this.v1;
				this.v0 += this.v3;
				this.v1 = rotateLeft(this.v1, 17);
				this.v3 = rotateLeft(this.v3, 21);

				this.v1 ^= this.v2;
				this.v3 ^= this.v0;
				this.v2 = rotateLeft(this.v2, 32);
			}
		};
	}
	
	@Override
	public Slice hash(byte[] bytes, int offset, int length) {
		return new Slice(BytesLE.longToByteArray(siphash(c, d, init_v0, init_v1, init_v2, init_v3, Slice.of(bytes, offset, length))));
	}

	@Override
	public Slice hash() {
		return emptyHash;
	}
	
	@Override
	public String toString() {
		return "SipHashHasher["+c+"-"+d+"]";
	}
	

	private static final int DEFAULT_C = 2;
	private static final int DEFAULT_D = 4;
	
	private static final long INITIAL_V0 = 0x736f6d6570736575L;
	private static final long INITIAL_V1 = 0x646f72616e646f6dL;
	private static final long INITIAL_V2 = 0x6c7967656e657261L;
	private static final long INITIAL_V3 = 0x7465646279746573L;

	/**
	 * Internal 0A hashing implementation.
	 *
	 * Requires initial state being manually provided (to avoid allocation). The compression rounds
	 * must also be provided, as nothing will be validated in this layer (such as defaults).
	 *
	 * @param c the rounds of C compression to apply.
	 * @param d the rounds of D compression to apply.
	 * @param v0 the seeded initial value of v0.
	 * @param v1 the seeded initial value of v1.
	 * @param v2 the seeded initial value of v2.
	 * @param v3 the seeded initial value of v3.
	 * @param data the input data to hash using the SipHash algorithm.
	 * @return a long value as the output of the hash.
	 */
	private static long siphash(int c, int d, long v0, long v1, long v2, long v3, byte[] data) {
		long m;
		int last = data.length / 8 * 8;
		int i = 0;
		int r;

		while (i < last) {
			m = data[i++] & 0xffL;
			for (r = 1; r < 8; r++) {
				m |= (data[i++] & 0xffL) << (r * 8);
			}

			v3 ^= m;
			for (r = 0; r < c; r++) {
				v0 += v1;
				v2 += v3;
				v1 = rotateLeft(v1, 13);
				v3 = rotateLeft(v3, 16);

				v1 ^= v0;
				v3 ^= v2;
				v0 = rotateLeft(v0, 32);

				v2 += v1;
				v0 += v3;
				v1 = rotateLeft(v1, 17);
				v3 = rotateLeft(v3, 21);

				v1 ^= v2;
				v3 ^= v0;
				v2 = rotateLeft(v2, 32);
			}
			v0 ^= m;
		}

		m = 0;
		for (i = data.length - 1; i >= last; --i) {
			m <<= 8;
			m |= (data[i] & 0xffL);
		}
		m |= (long) data.length << 56;

		v3 ^= m;
		for (r = 0; r < c; r++) {
			v0 += v1;
			v2 += v3;
			v1 = rotateLeft(v1, 13);
			v3 = rotateLeft(v3, 16);

			v1 ^= v0;
			v3 ^= v2;
			v0 = rotateLeft(v0, 32);

			v2 += v1;
			v0 += v3;
			v1 = rotateLeft(v1, 17);
			v3 = rotateLeft(v3, 21);

			v1 ^= v2;
			v3 ^= v0;
			v2 = rotateLeft(v2, 32);
		}
		v0 ^= m;

		v2 ^= 0xff;
		for (r = 0; r < d; r++) {
			v0 += v1;
			v2 += v3;
			v1 = rotateLeft(v1, 13);
			v3 = rotateLeft(v3, 16);

			v1 ^= v0;
			v3 ^= v2;
			v0 = rotateLeft(v0, 32);

			v2 += v1;
			v0 += v3;
			v1 = rotateLeft(v1, 17);
			v3 = rotateLeft(v3, 21);

			v1 ^= v2;
			v3 ^= v0;
			v2 = rotateLeft(v2, 32);
		}

		return v0 ^ v1 ^ v2 ^ v3;
	}

	// This is very close to {@link Long#rotateLeft(long, int)} aside from the use of the 64 bit masking.
	private static long rotateLeft(long value, int shift) {
		return (value << shift) | value >>> (64 - shift);
	}

}
