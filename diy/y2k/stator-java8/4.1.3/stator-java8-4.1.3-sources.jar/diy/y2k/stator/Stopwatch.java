/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator;

import java.time.Duration;
import java.util.OptionalLong;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import diy.y2k.stator.lipstick.MonotonicTime;

/**
 * Convenience class for timing sections of code and pretty-printing the elapsed duration.
 */
public class Stopwatch {

	private final LongSupplier timeSource;
	private long start;
	private long end = -1;

	public Stopwatch() {
		this(MonotonicTime::nanos);
	}
	
	public Stopwatch(LongSupplier timeSource) {
		this.timeSource = timeSource;
		this.start = timeSource.getAsLong();
	}
	
	public long getStart() {
		return start;
	}
	
	public OptionalLong getEnd() {
		return end == -1 ? OptionalLong.empty() : OptionalLong.of(end);
	}
	
	public void stop() {
		end = timeSource.getAsLong();
	}
	
	public void reset() {
		start = timeSource.getAsLong();
		end = -1;
	}
	
	public Duration getDuration() {
		long end = this.end == -1 ? timeSource.getAsLong() : this.end;
		return Duration.ofNanos(end-start);
	}
	
	@Override
	public String toString() {
		return formatElapsedTime(getDuration());
	}
	
	public static String timeRunnable(Runnable r) {
		long start = MonotonicTime.nanos();
		r.run();
		return formatElapsedTime(MonotonicTime.nanos()-start, TimeUnit.NANOSECONDS);
	}
	
	public static Duration durationRunnable(Runnable r) {
		long start = MonotonicTime.nanos();
		r.run();
		return Duration.ofNanos(MonotonicTime.nanos()-start);
	}
	
	public static CloseStopwatch time(Consumer<String> printer) {
		long start = MonotonicTime.nanos();
		return () -> {
			printer.accept(formatElapsedTime(MonotonicTime.nanos()-start, TimeUnit.NANOSECONDS));
		};
	}
	
	public static CloseStopwatch duration(Consumer<Duration> callback) {
		long start = MonotonicTime.nanos();
		return () -> {
			callback.accept(Duration.ofNanos(MonotonicTime.nanos()-start));
		};
	}
	
	public interface CloseStopwatch extends AutoCloseable {
		@Override void close();
	}

	private static final long MICROSECOND = 1000;
	private static final long MILLISECOND = MICROSECOND*1000;
	private static final long SECOND = MILLISECOND*1000;
	private static final long MINUTE = SECOND*60;
	private static final long HOUR = MINUTE*60;
	private static final long DAY = HOUR*24;
	private static final long WEEK = DAY*7;

	public static String formatElapsedTime(Duration dur) {
		return formatElapsedTime(dur.toNanos(), TimeUnit.NANOSECONDS);
	}
	
	public static String formatElapsedTime(long time, TimeUnit unit) {
		long elapsed = unit.toNanos(time);
		if (elapsed > 2*SECOND) {
			// just for fun: weeks and days
			long w = elapsed/WEEK;
			long d = (elapsed/DAY)%7;
			long h = (elapsed/HOUR)%24;
			long m = (elapsed/MINUTE)%60;
			long s = (elapsed/SECOND)%60;
			long ms = (elapsed/MILLISECOND)%1000;
			long cs = ms/100;
			var sb = new StringBuilder();
			if (w > 0) sb.append(w).append("w");
			if (d > 0) sb.append(d).append("d");
			if (h > 0) sb.append(h).append("h");
			if (m > 0) sb.append(m).append("m");
			if (d == 0 && s > 0) {
				sb.append(s);
				if (cs > 0 && h == 0) sb.append(".").append(cs);
				sb.append("s");
			}
			return sb.toString();
		} else if (elapsed > MILLISECOND) {
			long ms = elapsed/MILLISECOND;
			return ms+"ms";
		} else {
			long µs = elapsed/MICROSECOND;
			return µs+"µs";
		}
	}
	
}
