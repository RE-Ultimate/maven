/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.distill;

import java.util.function.Consumer;

/**
 * An object that can be deconstructed into an ordered stream of primitives.
 */
public interface Distillable {
	void distill(Still out);
	
	static int hashCode(Distillable d) {
		return hashCodeGeneric(d::distill);
	}
	
	static int hashCodeGeneric(Consumer<? super HashCodeStill> d) {
		var still = new HashCodeStill();
		d.accept(still);
		return still.hashCode();
	}
	
	static boolean equals(Distillable a, Distillable b) {
		return equalsGeneric(a::distill, b::distill);
	}
	
	static boolean equalsGeneric(Consumer<? super EqualsStill> a, Consumer<? super EqualsStill> b) {
		var still = new EqualsStill();
		a.accept(still);
		still.swap();
		b.accept(still);
		return still.equals();
	}
}
