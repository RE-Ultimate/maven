/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.distill;

public interface SerialStill extends Still {

	@Override
	default void putBooleans(boolean[] b, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putBoolean(b[ofs+i]);
	}

	@Override
	default void putBytes(byte[] b, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putByte(b[ofs+i]);
	}

	@Override
	default void putChars(char[] c, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putChar(c[ofs+i]);
	}

	@Override
	default void putShorts(short[] s, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putShort(s[ofs+i]);
	}

	@Override
	default void putInts(int[] a, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putInt(a[ofs+i]);
	}

	@Override
	default void putLongs(long[] l, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putLong(l[ofs+i]);
	}

	@Override
	default void putFloats(float[] f, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putFloat(f[ofs+i]);
	}

	@Override
	default void putDoubles(double[] d, int ofs, int len) {
		putInt(len);
		for (int i = 0; i < len; i++) putDouble(d[ofs+i]);
	}
	
}
