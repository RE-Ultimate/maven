/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.multi;

import java.util.Iterator;
import java.util.Set;

/**
 * A Set that can contain duplicate elements, tracking how many of them as a count.
 */
public interface Multiset<E> extends Set<E> {

	/**
	 * <b>Note</b>: The cardinality of a multiset is the sum of the multiplicity of every element,
	 * <i>i.e.</i> {@code [1, 1, 2].size() == 3} (not 2!)
	 * <p>
	 * {@inheritDoc}
	 */
	@Override
	int size();
	
	/**
	 * <b>Note</b>: This will iterate over multiplicitous elements <i>multiple times</i>. For unique
	 * elements, use {@link #elementSet} or {@link #entrySet}.
	 * <p>
	 * {@inheritDoc}
	 */
	@Override
	Iterator<E> iterator();
	
	
	/**
	 * @return the multiplicity of the given element of this multiset, or 0 if it does not contain it
	 */
	int count(Object element);
	
	/**
	 * Add {@code count} occurrences of {@code element} to this multiset.
	 * @return the multiplcity of the element <i>before</i> this addition
	 */
	int add(E element, int count);
	
	/**
	 * Remove up to {@code count} occurences of {@code element} from this multiset. The element will
	 * be removed completely if {@code count} is greater than or equal to its current multiplicity.
	 * @return the multiplicity of the element <i>before</i> this removal &mdash; can be used to
	 * 		determine how many elements were not removed, if any
	 */
	int remove(Object element, int count);
	
	/**
	 * Remove or add as many occurences of {@code element} to this multiset as is required to make
	 * its new multiplicity {@code newCount}.
	 * @return the multiplicity of the element <i>before</i> this change
	 */
	int setCount(E element, int newCount);
	
	/**
	 * Remove or add as many occurences of {@code element} to this multiset as is required to make
	 * its new multiplicity {@code newCount}, <i>if and only if</i> its multiplicity is presently
	 * equal to {@code expectedCount}.
	 * @return the multiplicity of the element <i>before</i> this change &mdash; if it is equal to
	 * 		{@code expectedCount}, the operation was successful
	 */
	int exchangeCount(E element, int expectedCount, int newCount);
	
	/**
	 * <b>Note</b>: Removal from the returned view will result in <i>all</i> occurences of an element
	 * being removed.
	 * @return a view of every <i>unique</i> element in this multiset
	 */
	Set<E> elementSet();
	
	/**
	 * @return a <i>read-only view</i> of every entry in this multiset; each unique element associated with its count
	 */
	Set<Entry<E>> entrySet();
	
	interface Entry<E> {
		/**
		 * @return the element represented by this entry
		 */
		E element();
		/**
		 * @return the multiplicity of the element represented by this entry
		 */
		int count();
	}
	
}
