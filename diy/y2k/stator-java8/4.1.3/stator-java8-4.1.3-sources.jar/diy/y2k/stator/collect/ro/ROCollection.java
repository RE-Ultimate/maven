/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.ro;

import java.util.Collection;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import java.util.function.Predicate;
import java.util.stream.Stream;

import diy.y2k.stator.exception.ReadOnlyException;

/**
 * A read-only/"unmodifiable" collection that codifies that immutability into its API contract.
 */
@SuppressWarnings("unlikely-arg-type")



public class ROCollection<E> implements Collection<E>



{
	private final Collection<E> underlying;
	
	ROCollection(Collection<E> underlying) {
		this.underlying = underlying;
	}

	@Override
	public ROIterator<E> iterator() { return new ROIterator<>(underlying.iterator()); }
	@Override
	public String toString() { return underlying.toString(); }
	

	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final boolean add(E e) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final boolean addAll(Collection<? extends E> c) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final void clear() { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final boolean remove(Object o) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final boolean removeAll(Collection<?> c) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final boolean retainAll(Collection<?> c) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public final boolean removeIf(Predicate<? super E> filter) { throw new ReadOnlyException(); }
	
	@Override
	public void forEach(Consumer<? super E> action) { underlying.forEach(action); }
	@Override
	public int size() { return underlying.size(); }
	@Override
	public boolean isEmpty() { return underlying.isEmpty(); }
	@Override
	public boolean contains(Object o) { return underlying.contains(o); }
	@Override
	public Object[] toArray() { return underlying.toArray(); }
	@Override
	public <T> T[] toArray(T[] a) { return underlying.toArray(a); }
	@Override
	public boolean containsAll(Collection<?> c) { return underlying.containsAll(c); }
	@Override
	public boolean equals(Object o) { return underlying.equals(o); }
	@Override
	public int hashCode() { return underlying.hashCode(); }
	@Override
	public Spliterator<E> spliterator() { return new ROSpliterator<>(underlying.spliterator()); }
	@Override
	public Stream<E> stream() { return underlying.stream(); }
	@Override
	public Stream<E> parallelStream() { return underlying.parallelStream(); }




	
}
