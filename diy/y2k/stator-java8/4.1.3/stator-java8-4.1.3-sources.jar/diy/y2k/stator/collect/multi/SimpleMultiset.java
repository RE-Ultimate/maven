/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.multi;

import java.util.AbstractSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import diy.y2k.stator.collect.TransformingIterator;

/**
 * A Multiset implementation that wraps an underlying Map.
 */
public class SimpleMultiset<E> extends AbstractMultiset<E> {

	private final Map<E, Integer> underlying;
	
	/**
	 * Create a SimpleMultiset backed by a HashMap.
	 */
	public SimpleMultiset() {
		this(new HashMap<>());
	}
	
	public SimpleMultiset(Map<E, Integer> underlying) {
		this.underlying = underlying;
	}

	@Override
	public int size() {
		int sum = 0;
		for (var en : underlying.values()) {
			sum += en;
		}
		return sum;
	}
	
	@Override
	@SuppressWarnings("unlikely-arg-type")
	public boolean contains(Object o) {
		return underlying.containsKey(o);
	}
	
	@Override
	public Iterator<E> iterator() {
		var iter = underlying.entrySet().iterator();
		return new Iterator<>() {
			private static final Object UNSTARTED = new Object();
			private static final Object EOS = new Object();
			
			private Object element = UNSTARTED;
			private int count = 0;
			
			private boolean pumped = false;

			@Override
			public boolean hasNext() {
				if (element == EOS) return false;
				if (count == 0) {
					if (!iter.hasNext()) {
						element = EOS;
						return false;
					}
					var en = iter.next();
					element = en.getKey();
					count = en.getValue();
				}
				count--;
				pumped = true;
				return true;
			}

			@Override
			@SuppressWarnings("unchecked")
			public E next() {
				if (element == EOS) throw new NoSuchElementException();
				if (element == UNSTARTED) throw new IllegalStateException();
				if (!pumped) throw new IllegalStateException();
				pumped = false;
				return (E)element;
			}
			
			@Override
			public void remove() {
				if (element == EOS) throw new NoSuchElementException();
				if (element == UNSTARTED) throw new IllegalStateException();
				count--;
				SimpleMultiset.this.remove(element, 1);
			}
		};
	}

	@Override
	public int count(Object element) {
		return underlying.getOrDefault(element, 0);
	}

	@Override
	public int add(E element, int count) {
		if (count < 0) return remove(element, -count);
		int old = count(element);
		if (count == 0) return old;
		underlying.compute(element, (unused, c) -> {
			if (c == null) c = 0;
			c += count;
			return c;
		});
		return old;
	}

	@Override
	@SuppressWarnings("unchecked")
	public int remove(Object element, int count) {
		int old = count(element);
		underlying.computeIfPresent((E)element, (unused, c) -> {
			c -= count;
			if (c <= 0) return null;
			return c;
		});
		return old;
	}

	@Override
	public int setCount(E element, int newCount) {
		int old = count(element);
		underlying.put(element, newCount);
		return old;
	}

	@Override
	public Set<E> elementSet() {
		return underlying.keySet();
	}

	@Override
	public Set<Multiset.Entry<E>> entrySet() {
		var entrySet = underlying.entrySet();
		return new AbstractSet<>() {

			@Override
			public int size() {
				return entrySet.size();
			}

			@Override
			public Iterator<Multiset.Entry<E>> iterator() {
				return new TransformingIterator<>(entrySet.iterator(), en -> new AbstractMultiset.Entry<>(en.getKey(), en.getValue()));
			}
		};
	}

}
