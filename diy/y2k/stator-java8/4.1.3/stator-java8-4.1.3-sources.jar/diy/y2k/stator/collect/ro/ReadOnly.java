/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.ro;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import diy.y2k.stator.collect.multi.Multiset;
import diy.y2k.stator.collect.multi.SimpleMultiset;

public final class ReadOnly {


















	private static final ROList<?> EMPTY_LIST = new ROList<>(Collections.emptyList());
	private static final ROSet<?> EMPTY_SET = new ROSet<>(Collections.emptySet(), null);
	private static final ROMap<?, ?> EMPTY_MAP = new ROMap<>(Collections.emptyMap());

	public static <E> ROList<E> list(E only) { return new ROList<>(Collections.singletonList(only)); }

	public static <E> ROList<E> list(E first, E second) { return list(first, second); }
	@SafeVarargs
	public static <E> ROList<E> list(E... elements) { return new ROList<>(Arrays.asList(elements)); }


	public static <E> ROSet<E> set(E only) { return new ROSet<>(Collections.singleton(only), null); }

	public static <E> ROSet<E> set(E first, E second) { return set(first, second); }
	@SafeVarargs
	public static <E> ROSet<E> set(E... elements) { return new ROSet<>(new HashSet<>(Arrays.asList(elements)), null); }

	
	private static final ROMultiset<?> EMPTY_MULTISET = new ROMultiset<>(new SimpleMultiset<>(map()));

	@SuppressWarnings("unchecked")
	public static <E> ROList<E> list() { return (ROList<E>)EMPTY_LIST; }
	@SuppressWarnings("unchecked")
	public static <E> ROSet<E> set() { return (ROSet<E>)EMPTY_SET; }
	@SuppressWarnings("unchecked")
	public static <K, V> ROMap<K, V> map() { return (ROMap<K, V>)EMPTY_MAP; }
	@SuppressWarnings("unchecked")
	public static <E> ROMultiset<E> multiset() { return (ROMultiset<E>)EMPTY_MULTISET; }
	
	
	public static <E> ROList<E> copyOf(List<? extends E> list) { return new ROList<>(new ArrayList<>(list)); }
	public static <E> ROSet<E> copyOf(Set<? extends E> set) { return new ROSet<>(new LinkedHashSet<>(set), null); }
	public static <K, V> ROMap<K, V> copyOf(Map<? extends K, ? extends V> map) { return new ROMap<>(new LinkedHashMap<>(map)); }
	
	public static <E> ROMultiset<E> copyOf(Multiset<E> multiset) {
		var rw = new SimpleMultiset<E>(new LinkedHashMap<>());
		for (var en : multiset.entrySet()) {
			rw.setCount(en.element(), en.count());
		}
		return new ROMultiset<>(rw);
	}
	













	public static <E> Collector<E, ?, ROList<E>> listCollector() {
		return Collectors.collectingAndThen(Collectors.toList(), ReadOnly::copyOf);
	}

	public static <E> Collector<E, ?, ROSet<E>> setCollector() {
		return Collectors.collectingAndThen(Collectors.toSet(), ReadOnly::copyOf);
	}

	public static <T, K, V> Collector<T, ?, ROMap<K, V>> mapCollector(Function<? super T, ? extends K> keyMapper, Function<? super T, ? extends V> valueMapper) {
		return Collectors.collectingAndThen(Collectors.<T, K, V>toMap(keyMapper, valueMapper), ReadOnly::copyOf);
	}

	
	private ReadOnly() {}

}
