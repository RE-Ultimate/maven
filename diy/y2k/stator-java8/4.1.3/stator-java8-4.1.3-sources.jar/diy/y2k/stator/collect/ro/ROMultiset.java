/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.ro;

import diy.y2k.stator.collect.multi.Multiset;
import diy.y2k.stator.exception.ReadOnlyException;

public final class ROMultiset<E> extends ROSet<E> implements Multiset<E> {

	private final Multiset<E> underlying;
	
	ROMultiset(Multiset<E> underlying) {
		super(underlying, null);
		this.underlying = underlying;
		entrySet = new ROSet<>(underlying.entrySet(), null);
		elementSet = new ROSet<>(underlying.elementSet(), null);
	}
	
	@Override
	public int count(Object element) {
		return underlying.count(element);
	}
	
	private final ROSet<Entry<E>> entrySet;
	private final ROSet<E> elementSet;
	
	@Override
	public ROSet<Entry<E>> entrySet() {
		return entrySet;
	}
	
	@Override
	public ROSet<E> elementSet() {
		return elementSet;
	}
	
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public int add(E element, int count) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public int remove(Object element, int count) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public int exchangeCount(E element, int expectedCount, int newCount) { throw new ReadOnlyException(); }
	/** @deprecated Always throws ReadOnlyException. */
	@Override @Deprecated
	public int setCount(E element, int newCount) { throw new ReadOnlyException(); }

}
