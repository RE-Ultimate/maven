/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.distill;

import diy.y2k.stator.io.Slice;

public class HashCodeStill implements FlexibleStill, SerialStill {
	
	private static final int PRIME = 37;
	
	private int hash = 1;

	@Override
	public void putBoolean(boolean b) {
		hash = (PRIME * hash) + (b ? PRIME : 0);
	}
	
	@Override
	public void putByte(byte b) {
		hash = (PRIME * hash) + b;
	}

	@Override
	public void putShort(short s) {
		hash = (PRIME * hash) + s;
	}
	
	@Override
	public void putChar(char c) {
		hash = (PRIME * hash) + c;
	}

	@Override
	public void putInt(int i) {
		hash = (PRIME * hash) + i;
	}

	@Override
	public void putLong(long l) {
		hash = (PRIME * hash) + Long.hashCode(l);
	}

	@Override
	public void putFloat(float f) {
		putInt(Float.floatToIntBits(f));
	}

	@Override
	public void putDouble(double d) {
		putDouble(Double.doubleToLongBits(d));
	}

	@Override
	public void put(String s) {
		// Strings cache their hashCode, take advantage of that
		putInt(s.hashCode());
	}
	
	@Override
	public void putNonDistillable(Object o) {
		if (o == null) {
			putInt(0);
		} else {
			putInt(PRIME);
			putInt(o.hashCode());
		}
	}

	@Override
	public void put(Distillable d) {
		if (d == null) {
			putInt(0);
		} else {
			putInt(PRIME);
			d.distill(this);
		}
	}
	
	@Override
	public void put(Slice s) {
		putBytes(s.toByteArray());
	}
	
	@Override
	public int hashCode() {
		return hash;
	}
	
}
