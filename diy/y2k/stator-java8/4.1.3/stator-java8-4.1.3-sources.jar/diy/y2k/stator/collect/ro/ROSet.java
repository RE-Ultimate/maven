/*
 * Stator - a somewhat opinionated collection of assorted utilities for Java
 * Copyright (c) 2019 - 2026 Exa Skye & Falkreon
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package diy.y2k.stator.collect.ro;

import java.util.Set;
import java.util.function.Function;
import java.util.function.IntFunction;

import org.checkerframework.checker.nullness.qual.Nullable;

import diy.y2k.stator.collect.TransformingIterator;

/**
 * A read-only/"unmodifiable" set that codifies that immutability into its API contract.
 */



public class ROSet<E> extends ROCollection<E> implements Set<E>



{
	private final Set<E> underlying;
	private final @Nullable Function<E, E> transformer;
	
	ROSet(Set<E> underlying, @Nullable Function<E, E> transformer) {
		super(underlying);
		this.underlying = underlying;
		this.transformer = transformer;
	}
	
	@Override
	public ROIterator<E> iterator() {
		var iter = underlying.iterator();
		if (transformer != null) iter = new TransformingIterator<>(iter, transformer);
		return new ROIterator<>(iter);
	}

	@Override @SuppressWarnings("unchecked")
	public <T> T[] toArray(T[] a) {
		super.toArray(a);
		if (transformer != null) {
			for (int i = 0; i < a.length; i++) {
				a[i] = (T)transformer.apply((E)a[i]);
			}
		}
		return a;
	}
	
	@Override
	public Object[] toArray() { return toArray(Object[]::new); }



	public <T> T[] toArray(IntFunction<T[]> generator) { return toArray(generator.apply(size())); }
}
